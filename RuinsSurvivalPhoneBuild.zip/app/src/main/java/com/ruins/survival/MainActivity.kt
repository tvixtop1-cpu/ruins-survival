package com.ruins.survival
import android.app.*
import android.os.*
import android.webkit.*
import android.widget.*
import java.net.*
import org.java_websocket.server.WebSocketServer
import org.java_websocket.WebSocket
import org.java_websocket.handshake.ClientHandshake

class LanServer(port:Int): WebSocketServer(InetSocketAddress(port)) {
    override fun onOpen(c:WebSocket,h:ClientHandshake){ c.send("""{"t":"welcome"}""") }
    override fun onClose(c:WebSocket,code:Int,reason:String,remote:Boolean){}
    override fun onMessage(c:WebSocket,m:String){ broadcast(m) }
    override fun onError(c:WebSocket?,e:Exception){}
    override fun onStart(){}
}
class MainActivity:Activity(){
    lateinit var web:WebView
    var server:LanServer?=null
    override fun onCreate(b:Bundle?){super.onCreate(b)
        web=WebView(this); web.settings.javaScriptEnabled=true; web.settings.domStorageEnabled=true
        web.addJavascriptInterface(object{ @android.webkit.JavascriptInterface fun host(){
            Thread{
                try{
                    server=LanServer(8765); server!!.start()
                    val ip=NetworkInterface.getNetworkInterfaces().toList().flatMap{it.inetAddresses.toList()}
                        .firstOrNull{!it.isLoopbackAddress && it.hostAddress.indexOf(':')<0}?.hostAddress ?: "192.168.x.x"
                    runOnUiThread{ web.evaluateJavascript("window.hostReady('${ip}:8765')",null) }
                }catch(e:Exception){runOnUiThread{web.evaluateJavascript("window.hostReady('Ошибка: ${e.message}')",null)}}
            }.start()
        }},"Android")
        setContentView(web); web.loadUrl("file:///android_asset/index.html")
    }
    override fun onDestroy(){server?.stop();super.onDestroy()}
}